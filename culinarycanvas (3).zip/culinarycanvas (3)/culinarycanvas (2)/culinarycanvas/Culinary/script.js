// Get all the plus and minus buttons
const plusButtons = document.querySelectorAll('.plus');
const minusButtons = document.querySelectorAll('.minus');

// Add event listeners to each plus button
plusButtons.forEach(button => {
    button.addEventListener('click', () => {
        // Get the corresponding counter element
        const counter = button.parentNode.querySelector('span');
        // Increment the counter value
        counter.textContent = parseInt(counter.textContent) + 1;
    });
});

// Add event listeners to each minus button
minusButtons.forEach(button => {
    button.addEventListener('click', () => {
        // Get the corresponding counter element
        const counter = button.parentNode.querySelector('span');
        // Decrement the counter value, but make sure it doesn't go below 1
        if (parseInt(counter.textContent) > 1) {
            counter.textContent = parseInt(counter.textContent) - 1;
        }
    });
});
